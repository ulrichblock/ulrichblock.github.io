<?php
/**
 * Validator Klasse zum �berpr�fen von Userinput
 *
 * @author     Ulrich Block <ulblock@gmx.de>
 * @link       http://www.ulrich-block.de
 * @copyright  2012 Ulrich Block
 * @license    GNU Public License <http://www.gnu.org/licenses/gpl.html>
 * @version    v1.0 released 03.03.2008
 */

// Die Superglobals leeren, nachdem sie in das Object �bergeben worden sind.
$ui=new ValidateUserinput($_GET,$_POST,$_SERVER,$_REQUEST,$_ENV);
unset($_GET);
unset($_POST);
unset($_SERVER);
unset($_REQUEST);
unset($_ENV);

// Ab hier w�rde dann der restliche PHP Code beginnen.
// Die einzelnen Werte werden dadurch aufgerufen, dass man mit der Funktion bestimmt, auf was der Wert �berpr�ft werden soll.
// Mit dem ersten Wert sagt man, welcher Key gew�nscht ist, mit dem zweiten Wert sagt man, von welcher der vorherigen Superglobals der Wert genommen werden soll.
// Bei dem Beispielaufruf datei.php?w=test w�rde test ausgegeben werden
if ($ui->smallletters('w','get')) echo $ui->smallletters('w','get');
else echo 'Nicht validiert';


?>