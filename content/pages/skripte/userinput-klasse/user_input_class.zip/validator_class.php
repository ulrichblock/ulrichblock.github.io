<?php

/**
 * Validator Klasse zum überprüfen von Userinput
 *
 * @author     Ulrich Block <ulblock@gmx.de>
 * @link       http://www.ulrich-block.de
 * @copyright  2012 Ulrich Block
 * @license    GNU Public License <http://www.gnu.org/licenses/gpl.html>
 * @version    v1.0 released 03.03.2008
 */
 
class ValidateUserinput {
	public $get=array();
	public $post=array();
	public $server=array();
	public $request=array();
	public $env=array();
	
	// Wenn die Magic Quotes zum escapen eingesetzt werden, dann mit stripcslashes entfernen.
	// Dies ist erforderlich, wenn man Klassen wie PDO einsetzt, die zusätzlich escapen.
	private function magic_quotes ($value) {
		if (function_exists('get_magic_quotes_gpc') and get_magic_quotes_gpc()==1) {
			$value=stripcslashes($value); 
		}
		return $value;
	}
	
	// Wenn die Magic Quotes nicht zum escapen eingesetzt werden, dann diesen Codepart benutzen, um mit addcslashes zu escapen.
	// Dies ist immer dann erforderlich, wenn man eine Datenbankverbindung, wie mysql_connect(); benutzt, die nicht selber escaped.
	// private function magic_quotes ($value) {
	// 	if (!function_exists('get_magic_quotes_gpc') or get_magic_quotes_gpc()==0) {
	// 		$value=addcslashes($value);
	// 	}
	// 	return $value;
	// }
	
	// Wandelt Arrays, die innerhalb der Superglobals bestehen in Objekte um
	private function ArrayToObject($array) {
		if(is_string($array)) {
			return $this->magic_quotes($array);
		} else if (is_array($array)) {
			$stdClass = new stdClass();
			foreach ($array as $key => $value) {
				$stdClass->$key = $this->ArrayToObject($value);
			}
			return $stdClass; 
		} else {
			return false;
		}
	}
	
	// Constructor
	function __construct($get,$post,$server,$request,$env) {
		foreach ($get as $key => $value) {
			if (is_string($value)) {
				$this->get[$key] = $this->magic_quotes($value);
			} else if (is_array($value)) {
				$this->get[$key] = $this->ArrayToObject($value);
			}
		}
		foreach ($post as $key => $value) {
			if (is_string($value)) {
				$this->post[$key] = $this->magic_quotes($value);
			} else if (is_array($value)) {
				$this->post[$key] = $this->ArrayToObject($value);
			}
		}
		foreach ($server as $key => $value) {
			if (is_string($value)) {
				$this->server[$key] = $this->magic_quotes($value);
			} else if (is_array($value)) {
				$this->server[$key] = $this->ArrayToObject($value);
			}
		}
		foreach ($request as $key => $value) {
			if (is_string($value)) {
				$this->request[$key] = $this->magic_quotes($value);
			} else if (is_array($value)) {
				$this->request[$key] = $this->ArrayToObject($value);
			}
		}
		foreach ($env as $key => $value) {
			if (is_string($value)) {
				$this->env[$key] = $this->magic_quotes($value);
			} else if (is_array($value)) {
				$this->env[$key] = $this->ArrayToObject($value);
			}
		}
	}
	
	// Destructor
	function __destruct() {
		unset($this->get);
		unset($this->post);
		unset($this->server);
		unset($this->reques);
		unset($this->env);
	}
	
	// Wird der Userinput in Form eines Arrays abgeschickt, ist es erforderlich das Array zu loopen, um alle daten validieren zu können.
	// Beispiele:
	// 	<input type="text" name="array[]" />
	// 	<input type="text" name="array[key][]" />
	private function loop ($check,$function,$type,$length=null) {
		if(is_string($check) and $length==null and $this->$function($check,$type)) {
			return $this->$function($check,$type);
		} else if(is_string($check) and $this->$function($check,$length,$type)) {
			return $this->$function($check,$length,$type);
		} else if (is_array($check) or is_object($check)) {
			$stdClass = new stdClass();
			foreach ($check as $key => $value) {
				if (is_string($value)) {
					$stdClass->$key = $value;
				} else {
					$stdClass->$key = $this->loop($value,$function,$type,$length);
				}
			}
			return $stdClass; 
		}
	}
	
	// Überprüfung ob ein Object, oder String vorliegt
	private function if_obj_or_str ($value,$type,$object) {
		if ($object==false and is_string($value) and !isset($this->$type)) {
			return $value;
		} else if ($object==false and isset($this->$type)) {
			$check=$this->$type;
			if (isset($check[$value])) {
				return $check[$value];
			}
		} else if ($object!=false and isset($this->$type)) {
			$check=$this->$type;
			if (isset($check[$value]->$object)) {
				return $check[$value]->$object;
			}
		} else {
			return false;
		}
	}
	
	// Urls
	function url ($value,$type,$object=false) {
		$check=$this->if_obj_or_str($value,$type,$object);
		if($check and is_string($check) and filter_var($check,FILTER_VALIDATE_URL)) {
			return $check;
		} else if ($check) {
			return $this->loop($check,'url',$type);
		}
	}
	
	// Domains
	function domain ($value,$type,$object=false) {	
		$check=$this->if_obj_or_str($value,$type,$object);
		if($check and is_string($check) and preg_match("/^[a-z\d+\-\.]+\.[a-z]{1,5}$/",$check)) {
			return $check;
		} else if ($check) {
			return $this->loop($check,'domain',$type);
		}
	}
	
	// Mails
	function mail ($value,$type,$object=false) {
		$check=$this->if_obj_or_str($value,$type,$object);
		if($check and is_string($check) and filter_var($check,FILTER_VALIDATE_EMAIL)) {
			return $check;
		}  else if ($check) {
			return $this->loop($check,'ismail',$type);
		}
	}
	
	// IP4 Adressen
	function ip4 ($value,$type,$object=false) {
		$check=$this->if_obj_or_str($value,$type,$object);
		if($check and is_string($check) and filter_var($check,FILTER_VALIDATE_IP,FILTER_FLAG_IPV4)){
			return $check;
		} else if ($check) {
			return $this->loop($check,'ip4',$type);
		}
	}
	
	// IP6 Adressen
	function ip6 ($value,$type,$object=false) {
		$check=$this->if_obj_or_str($value,$type,$object);
		if($check and is_string($check) and filter_var($check,FILTER_VALIDATE_IP,FILTER_FLAG_IPV6)){
			return $check;
		} else if ($check) {
			return $this->loop($check,'ip6',$type);
		}
	}
	
	// IP4 und IP6 Filter
	function ip ($value,$type,$object=false) {
		$check=$this->if_obj_or_str($value,$type,$object);
		if($check and is_string($check) and filter_var($check,FILTER_VALIDATE_IP)){
			return $check;
		} else if ($check) {
			return $this->loop($check,'ip',$type);
		}
	}
	
	// Multiple IP4 Adressen
	function ips ($value,$type,$object=false) {
		$check=$this->if_obj_or_str($value,$type,$object);
		if ($check and is_string($check) and preg_match("/^[\r\n\.\/\d+]+$/",$check)) {
			return $check;
		} else if ($check) {
			return $this->loop($check,'ips',$type);
		}
	}
	
	// Mac Adresse
	function mac ($value,$type,$object=false) {
		$check=$this->if_obj_or_str($value,$type,$object);
		if ($check and is_string($check) and preg_match("/^[0-9a-fA-F]{2}:[0-9a-fA-F]{2}:[0-9a-fA-F]{2}:[0-9a-fA-F]{2}:[0-9a-fA-F]{2}:[0-9a-fA-F]{2}$/",$check)) {
			return $check;
		} else if ($check) {
			return $this->loop($check,'mac',$type);
		}
	}
	
	// Serverport
	function port ($value,$type,$object=false) {
		$check=$this->if_obj_or_str($value,$type,$object);
		if ($check and is_string($check) and preg_match("/^(0|([1-9]\d{0,3}|[1-5]\d{4}|[6][0-5][0-5]([0-2]\d|[3][0-5])))$/",$check)) {
			return $check;
		} else if ($check) {
			return $this->loop($check,'port',$type);
		}
	}
	
	// Pfadangaben
	function path ($value,$type,$object=false) {
		$check=$this->if_obj_or_str($value,$type,$object);
		if ($check and is_string($check) and preg_match("/^[\w\-\_\/]{1,}[\/]{1}$/",$check)) {
			return $check;
		} else if ($check) {
			return $this->loop($check,'path',$type);
		}
	}
	
	// A-Z, a-z und 0-9
	function pregw ($value,$length,$type,$object=false) {
		$check=$this->if_obj_or_str($value,$type,$object);
		if ($check and is_string($check) and preg_match('/^[\w]{1,'.$length.'}$/',$check)) {
			return $check;
		} else if ($check) {
			return $this->loop($check,'pregw',$type,$length);
		}
	}
	
	// Integer
	function isinteger ($value,$type,$object=false) {
		$check=$this->if_obj_or_str($value,$type,$object);
		if ($check and is_string($check)) {
			$value=str_replace(',', '.',$check);
			if(preg_match("/^[\d+(.\d+|$)]+$/",$value)) {
				return $value;
			}
		} else if ($check) {
			return $this->loop($check,'isinteger',$type);
		}
	}
	
	// Ja, oder nein (Y,N)
	function active ($value,$type,$object=false) {
		$check=$this->if_obj_or_str($value,$type,$object);
		if ($check and is_string($check) and preg_match("/^[N,Y]{1}$/",$check)) {
			return $check;
		} else if ($check) {
			return $this->loop($check,'active',$type);
		}
	}
	
	// Passwort
	function password ($value,$length,$type,$object=false) {
		$check=$this->if_obj_or_str($value,$type,$object);
		if ($check and is_string($check) and preg_match('/^[\w\[\]\(\)\<\>!\"§$%&\/=\?*+#]{1,'.$length.'}$/',$check)) {
			return $check;
		} else if ($check) {
			return $this->loop($check,'password',$type,$length);
		}
	}
	
	// Serverdienste in Form von IP:Port
	function ipport ($value,$type,$object=false) {
		$check=$this->if_obj_or_str($value,$type,$object);
		if ($check and is_string($check)) {
			$adresse_awk=explode(":",preg_replace('/\s+/','',str_replace(' ', "",$check)));
			if (isset($awk[1]) and filter_var($awk[0],FILTER_VALIDATE_IP,FILTER_FLAG_IPV4) and preg_match("/^(0|([1-9]\d{0,3}|[1-5]\d{4}|[6][0-5][0-5]([0-2]\d|[3][0-5])))$/",$awk[1])) {
				return $awk[0].':'.$awk[1];
			}
		} else if ($check) {
			return $this->loop($check,'ipport',$type);
		}
	}
	
	// Mapnamen der HL1 udn HL2 Engine
	function mapname ($value,$type,$object=false) {
		$check=$this->if_obj_or_str($value,$type,$object);
		if ($check and is_string($check)) {
			$replaced=str_replace(array(" ",".bsp"),array("",""),$check);
			if (preg_match("/^[\w\-\.\_ \/]+$/",$replaced)) {
				return $replaced;
			}
		} else if ($check) {
			return $this->loop($check,'mapname',$type);
		}
	}
	
	// Beschreibungen und Kommentare, HTML wird automatisch encoded
	function description ($value,$type,$object=false){
		$check=$this->if_obj_or_str($value,$type,$object);
		if ($check and is_string($check)) {
			$value=htmlentities($check,ENT_QUOTES,'UTF-8');
			if (preg_match("/^[\x{0400}-\x{04FF}\w\r\n\-():;&.,% ]+/u",$value)) {
				return $value;
			}
		} else if ($check) {
			return $this->loop($check,'description',$type);
		}
	}
	
	// Telefonnummer
	function phone ($value,$type,$object=false) {
		$check=$this->if_obj_or_str($value,$type,$object);
		if ($check and is_string($check) and preg_match('/^[\d+\+\(\)\/\-\s]+$/',$check)) {
			return $check;
		} else if ($check) {
			return $this->loop($check,'phone',$type);
		}
	}
	
	// IDs
	function id ($value,$length,$type,$object=false){
		$check=$this->if_obj_or_str($value,$type,$object);
		if ($check and is_string($check) and preg_match('/^[\d+]{1,'.$length.'}$/',$check)) {
			return $check;
		} else if ($check) {
			return $this->loop($check,'id',$type,$length);
		}
	}
	
	// Zeitangaben in der Form +-Stunden
	function timezone ($value,$type,$object=false) {
		$check=$this->if_obj_or_str($value,$type,$object);
		if ($check and is_string($check) and preg_match('/^1?[+-][\d+]$|^[+-][1][\d+]|^[+-][2][0-4]$/',$check)) {
			return $check;
		} else if ($check) {
			return $this->loop($check,'timezone',$type);
		}
	}
	
	// Benutzernamen
	function username ($value,$length,$type,$object=false) {
		$check=$this->if_obj_or_str($value,$type,$object);
		if ($check and is_string($check) and preg_match('/^[\w\-\.]{1,'.$length.'}$/',$check)) {
			return $check;
		} else if ($check) {
			return $this->loop($check,'username',$type,$length);
		}
	}
	
	// Namen
	function names ($value,$length,$type,$object=false) {
		$check=$this->if_obj_or_str($value,$type,$object);
		if ($check and is_string($check)) {
			$value=htmlentities($check,ENT_QUOTES,'UTF-8');
			if (preg_match('/^[\w\;\&\.\-\_\/ ]{1,'.$length.'}$/', $value)) {
				return $value;
			}
		} else if ($check) {
			return $this->loop($check,'names',$type,$length);
		}
	}
	
	// Kleine Buchstaben
	function smallletters ($value,$length,$type,$object=false) {
		$check=$this->if_obj_or_str($value,$type,$object);
		if ($check and is_string($check) and preg_match('/^[a-z]{1,'.$length.'}$/',$check)) {
			return $check;
		} else if ($check) {
			return $this->loop($check,'smallletters',$type,$length);
		}
	}
	
	// HTML Entities im Input encodieren
	function htmlcode ($value,$type,$object=false) {
		$check=$this->if_obj_or_str($value,$type,$object);
		if ($check and is_string($check)) {
			return htmlentities($check,ENT_QUOTES,'UTF-8');
		} else if ($check) {
			return $this->loop($check,'htmlcode',$type);
		}
	}
	
	// Den Input nicht validieren und wie vom User eingegeben ausgeben.
	function escaped ($value,$type,$object=false) {
		$check=$this->if_obj_or_str($value,$type,$object);
		if ($check and is_string($check)) {
			return $check;
		} else if ($check) {
			return $this->loop($check,'escaped',$type);
		} else {
			return false;
		}
	}
}
?>